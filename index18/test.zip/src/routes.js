import ProductList from './components/Products/ProductsList'


export const routes = [
   { path: '/', component: ProductList}
];
