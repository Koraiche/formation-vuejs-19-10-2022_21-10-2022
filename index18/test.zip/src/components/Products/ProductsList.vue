<template>
  <div>
    {{dataList}}
    
  </div>
</template>

<script>

import axios from "axios";

export default {
  data(){
    return {
        dataList: []
    }
  },
  methods:{
    fetch(){
        axios.get("http://localhost:9090/products").then((res)=>{
            this.dataList = res.data;

        }).catch((error)=>{
            console.log("error" + error);
        });
    }
  },
  beforeMount(){
    this.fetch();
  }
}
</script>
<style scoped>

</style>
